"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

export default function Footer({ weddingDate, playfair }) {
  return (
    <footer className="py-12 px-4 bg-rose-800 text-white text-center relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-4 h-4 rounded-full bg-white/10"
            initial={{
              x: Math.random() * 100 + "%",
              y: Math.random() * 100 + "%",
              scale: Math.random() * 0.5 + 0.5,
            }}
            animate={{
              y: [null, Math.random() * -200 - 100],
              opacity: [0.7, 0],
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.h2
          className={cn("text-3xl md:text-4xl font-bold mb-6", playfair.className)}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          We can't wait to celebrate with you!
        </motion.h2>

        <motion.p
          className="mb-8"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          Please RSVP by{" "}
          {new Date(weddingDate.getTime() - 30 * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
        </motion.p>

        <div className="flex flex-col sm:flex-row justify-center gap-6 mb-8">
          <motion.button
            whileHover={{ scale: 1.05, backgroundColor: "#fff", color: "#be123c" }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="bg-white text-rose-800 px-6 py-3 rounded-full font-semibold transition-colors"
          >
            RSVP Now
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.2)" }}
            whileTap={{ scale: 0.95 }}
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="bg-transparent border-2 border-white text-white px-6 py-3 rounded-full font-semibold transition-colors"
          >
            Contact Us
          </motion.button>
        </div>

        <motion.p
          className="text-rose-200"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          Made with love by John & Sarah
        </motion.p>
      </div>
    </footer>
  )
}
