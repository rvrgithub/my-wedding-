"use client"

import { motion } from "framer-motion"
import { MapPin } from "lucide-react"
import { cn } from "@/lib/utils"

export default function LocationMap({ playfair }) {
  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className={cn("text-4xl md:text-5xl font-bold text-rose-800 mb-4", playfair.className)}>
            Wedding Location
          </h2>
          <div className="w-24 h-1 bg-rose-300 mx-auto mb-8"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Join us at our beautiful wedding venue in the heart of New York City. Below you'll find directions to both
            the ceremony and reception locations.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="rounded-xl overflow-hidden shadow-xl h-[400px] md:h-[500px] relative"
        >
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.15830869428!2d-74.11976397304605!3d40.69766374874431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1620796614533!5m2!1sen!2s"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            title="Wedding Location"
          ></iframe>

          {/* Animated map pin */}
          <motion.div
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10"
            animate={{ y: [0, -20, 0] }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
          >
            <MapPin className="w-12 h-12 text-rose-600 drop-shadow-lg" />
          </motion.div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mt-12">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-rose-50 p-6 rounded-lg"
            whileHover={{ scale: 1.02 }}
          >
            <h3 className={cn("text-xl font-bold text-rose-700 mb-4", playfair.className)}>Ceremony Location</h3>
            <p className="text-gray-700 mb-2">St. Mary's Church</p>
            <p className="text-gray-600 mb-4">123 Wedding Lane, New York, NY 10001</p>
            <p className="text-gray-600 text-sm">
              <span className="font-semibold">Parking:</span> Available in the church parking lot and street parking
              nearby.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-rose-50 p-6 rounded-lg"
            whileHover={{ scale: 1.02 }}
          >
            <h3 className={cn("text-xl font-bold text-rose-700 mb-4", playfair.className)}>Reception Location</h3>
            <p className="text-gray-700 mb-2">Grand Ballroom, Luxury Hotel</p>
            <p className="text-gray-600 mb-4">456 Celebration Avenue, New York, NY 10001</p>
            <p className="text-gray-600 text-sm">
              <span className="font-semibold">Parking:</span> Valet parking available at the hotel entrance. Public
              parking garage located one block away.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
