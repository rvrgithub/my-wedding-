"use client"

import { motion } from "framer-motion"
import { Calendar, Clock, MapPin } from "lucide-react"
import { cn } from "@/lib/utils"

export default function WeddingDetails({ weddingDate, playfair }) {
  const detailsVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.2,
        duration: 0.8,
      },
    }),
  }

  return (
    <section className="py-20 px-4 bg-rose-50">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className={cn("text-4xl md:text-5xl font-bold text-rose-800 mb-4", playfair.className)}>
            Wedding Details
          </h2>
          <div className="w-24 h-1 bg-rose-300 mx-auto mb-8"></div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            custom={0}
            variants={detailsVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="bg-white p-8 rounded-xl shadow-lg"
          >
            <motion.div className="flex items-center mb-6" whileHover={{ x: 5 }}>
              <motion.div
                animate={{ rotate: [0, 10, 0, -10, 0] }}
                transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY }}
              >
                <Calendar className="w-8 h-8 text-rose-600 mr-4" />
              </motion.div>
              <h3 className={cn("text-2xl font-bold text-rose-700", playfair.className)}>Ceremony</h3>
            </motion.div>

            <ul className="space-y-4">
              <motion.li className="flex items-start" whileHover={{ x: 5 }}>
                <div className="w-6 h-6 rounded-full bg-rose-100 flex items-center justify-center mt-1 mr-3">
                  <Clock className="w-3 h-3 text-rose-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Date & Time</p>
                  <p className="text-gray-600">
                    {weddingDate.toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}{" "}
                    at 2:00 PM
                  </p>
                </div>
              </motion.li>

              <motion.li className="flex items-start" whileHover={{ x: 5 }}>
                <div className="w-6 h-6 rounded-full bg-rose-100 flex items-center justify-center mt-1 mr-3">
                  <MapPin className="w-3 h-3 text-rose-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Location</p>
                  <p className="text-gray-600">St. Mary's Church</p>
                  <p className="text-gray-600">123 Wedding Lane, New York, NY 10001</p>
                </div>
              </motion.li>
            </ul>
          </motion.div>

          <motion.div
            custom={1}
            variants={detailsVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="bg-white p-8 rounded-xl shadow-lg"
          >
            <motion.div className="flex items-center mb-6" whileHover={{ x: 5 }}>
              <motion.div
                animate={{ rotate: [0, 10, 0, -10, 0] }}
                transition={{ duration: 5, repeat: Number.POSITIVE_INFINITY }}
              >
                <Calendar className="w-8 h-8 text-rose-600 mr-4" />
              </motion.div>
              <h3 className={cn("text-2xl font-bold text-rose-700", playfair.className)}>Reception</h3>
            </motion.div>

            <ul className="space-y-4">
              <motion.li className="flex items-start" whileHover={{ x: 5 }}>
                <div className="w-6 h-6 rounded-full bg-rose-100 flex items-center justify-center mt-1 mr-3">
                  <Clock className="w-3 h-3 text-rose-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Date & Time</p>
                  <p className="text-gray-600">
                    {weddingDate.toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}{" "}
                    at 5:00 PM
                  </p>
                </div>
              </motion.li>

              <motion.li className="flex items-start" whileHover={{ x: 5 }}>
                <div className="w-6 h-6 rounded-full bg-rose-100 flex items-center justify-center mt-1 mr-3">
                  <MapPin className="w-3 h-3 text-rose-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-800">Location</p>
                  <p className="text-gray-600">Grand Ballroom, Luxury Hotel</p>
                  <p className="text-gray-600">456 Celebration Avenue, New York, NY 10001</p>
                </div>
              </motion.li>
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
