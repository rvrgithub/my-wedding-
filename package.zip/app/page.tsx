import WeddingInvitation from "@/components/wedding-invitation"

export default function Home() {
  return <WeddingInvitation />
}
